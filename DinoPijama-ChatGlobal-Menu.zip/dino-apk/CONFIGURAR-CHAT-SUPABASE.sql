-- Execute este script no Supabase: SQL Editor > New query > Run.
-- Usa o mesmo projeto Supabase já configurado no Dino Pijama.
create table if not exists public.chat_messages (
  id bigint generated always as identity primary key,
  player_id text not null check (length(player_id) between 1 and 80),
  player_name text not null check (length(player_name) between 1 and 12),
  message text not null check (length(message) between 1 and 240),
  created_at timestamptz not null default now()
);

create index if not exists chat_messages_created_at_idx
  on public.chat_messages (created_at desc);

alter table public.chat_messages enable row level security;

grant select, insert on public.chat_messages to anon, authenticated;
grant usage, select on sequence public.chat_messages_id_seq to anon, authenticated;

drop policy if exists "Chat publico pode ser lido" on public.chat_messages;
create policy "Chat publico pode ser lido"
  on public.chat_messages for select to anon, authenticated using (true);

drop policy if exists "Jogadores podem enviar mensagens" on public.chat_messages;
create policy "Jogadores podem enviar mensagens"
  on public.chat_messages for insert to anon, authenticated
  with check (
    length(player_id) between 1 and 80 and
    length(player_name) between 1 and 12 and
    length(message) between 1 and 240
  );
