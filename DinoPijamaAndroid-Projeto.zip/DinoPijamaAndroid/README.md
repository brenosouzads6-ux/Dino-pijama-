# Dino Pijama — projeto Android

Este projeto empacota o jogo HTML enviado como um aplicativo Android usando WebView. O jogo e os arquivos ficam dentro do APK; não precisa de internet para abrir.

## Gerar o APK

1. Abra este projeto no Android Studio (versão recente).
2. Aguarde a sincronização do Gradle e instale os componentes do Android SDK solicitados.
3. No menu **Build**, escolha **Build APK(s)**.
4. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações
- Identificador do app: `com.bzin.dinopijama`
- Versão: 1.0
- O APK ainda precisa ser compilado com o Android SDK. Este pacote é o projeto-fonte pronto para compilar, não um APK já compilado.
